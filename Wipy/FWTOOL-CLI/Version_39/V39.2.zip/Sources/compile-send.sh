#!/bin/bash
sh mpy-crosser.sh
read  -p "Appuyez sur entrer"
sh Upload_Project.sh
read -p "Appuyez sur entrée"